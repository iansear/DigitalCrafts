class User {
    constructor(username, password, trips) {
        this.username = username
        this.password = password
        this.trips = trips
    }
}

module.exports = User