class Trip {
    constructor(title, image, departDate, returnDate) {
        this.title = title,
        this.image = image,
        this.departDate = departDate,
        this.returnDate = returnDate
    }
}

module.exports = Trip