import React, { Component } from 'react';


class AboutUs extends Component {
  render() {
    return <h1>About Us</h1>
  }
}

export default AboutUs;
