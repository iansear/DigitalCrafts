import React, {Component} from 'react'

class Header extends Component {

    render() {
        return (<div className="header">
             <h1>High On Coding</h1>
             <h3>Home</h3>
             <h3>Categories</h3>
        </div>)
    }
}

export default Header