import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { setAuthenticationHeader } from './utils/authentication';
 
// set the authentication header when the person 
// has refreshed the page 
const token = localStorage.getItem('jsonwebtoken')
setAuthenticationHeader(token)

ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
